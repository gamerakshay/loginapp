package com.gamerakshay.loginapp;

public class UserProfile {
    public String userage;
    public String useremail;
    public String username;

    public UserProfile(String userage, String useremail, String username) {
        this.userage = userage;
        this.useremail = useremail;
        this.username = username;
    }
}
